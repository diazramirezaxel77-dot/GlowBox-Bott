require("dotenv").config();

const fs = require("fs");
const path = require("path");
const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

const PREFIX = process.env.PREFIX || "!";
const COLOR = process.env.COLOR || "#5865F2";
const FOOTER_TEXT = process.env.FOOTER_TEXT || "GlowBox〢Network 🚀";
const WELCOME_CHANNEL_ID = process.env.WELCOME_CHANNEL_ID || "";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel, Partials.Message, Partials.User]
});

const DATA_DIR = path.join(__dirname, "data");
const WARNS_FILE = path.join(DATA_DIR, "warns.json");
const BLACKLIST_FILE = path.join(DATA_DIR, "blacklist.json");
const GIVEAWAYS_FILE = path.join(DATA_DIR, "giveaways.json");

function ensureFile(file, fallback) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
}
ensureFile(WARNS_FILE, {});
ensureFile(BLACKLIST_FILE, {});
ensureFile(GIVEAWAYS_FILE, []);

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch { return fallback; }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function footer(embed) {
  return embed.setFooter({ text: `${FOOTER_TEXT} | ${new Date().toLocaleString("es-MX")}` });
}

function modEmbed(title, description, color = COLOR) {
  return footer(new EmbedBuilder().setColor(color).setTitle(title).setDescription(description));
}

function getMemberFromMention(message, arg) {
  const mentioned = message.mentions.members.first();
  if (mentioned) return mentioned;
  if (!arg) return null;
  return message.guild.members.cache.get(arg.replace(/[<@!>]/g, "")) || null;
}

function cleanReason(args, start) {
  return args.slice(start).join(" ") || "Sin razón especificada";
}

function hasModPermission(member) {
  return member.permissions.has(PermissionsBitField.Flags.ModerateMembers) ||
    member.permissions.has(PermissionsBitField.Flags.ManageGuild) ||
    member.permissions.has(PermissionsBitField.Flags.Administrator);
}

function hasAdminPermission(member) {
  return member.permissions.has(PermissionsBitField.Flags.Administrator) ||
    member.permissions.has(PermissionsBitField.Flags.ManageGuild);
}

function parseDuration(input) {
  if (!input) return null;
  const match = String(input).toLowerCase().match(/^(\d+(?:\.\d+)?)(m|h|d|s|ms|a)$/);
  if (!match) return null;
  const value = Number(match[1]);
  const unit = match[2];
  const multipliers = {
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    s: 7 * 24 * 60 * 60 * 1000,
    ms: 30 * 24 * 60 * 60 * 1000,
    a: 365 * 24 * 60 * 60 * 1000
  };
  return value * multipliers[unit];
}

function formatDuration(ms) {
  const sec = Math.max(1, Math.floor(ms / 1000));
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m`;
  const hours = Math.floor(min / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}

function parseGiveawayArgs(args) {
  if (args.length < 2) return null;
  const durationIndex = args.findIndex((x, i) => i > 0 && !!parseDuration(x));
  if (durationIndex === -1) return null;

  const prize = args.slice(0, durationIndex).join(" ");
  const duration = parseDuration(args[durationIndex]);
  const rest = args.slice(durationIndex + 1);

  let winners = 1;
  let host = null;

  if (rest.length && /^\d+$/.test(rest[0])) {
    winners = Math.max(1, Math.min(20, Number(rest.shift())));
  }

  const hostMention = rest.find(x => /^<@!?\d+>$/.test(x));
  if (hostMention) host = hostMention;

  return { prize, duration, winners, host };
}

function getUserAvatar(user) {
  return user.displayAvatarURL({ extension: "png", size: 1024 });
}

function welcomeEmbed(member) {
  const count = member.guild.memberCount;
  const now = new Date();

  const description = [
    `<:saludo_GlowBox:1544868878776016979>  ~  ${member}`,
    "",
    `<:yup_GlowBox:1544870017802178614>  ~  ***Bienvenido a "GlowBox", esperamos que te diviertas.***`,
    "",
    `<:fantasma_GlowBox:1544868865907892264>  ~  ***¡Somos ${count} personitas, Gracias por unirte!***`,
    "",
    `<:ClashBox_GlowBox:1544868832580083802> **IP →** ¡Próximamente!`,
    `<:palmera_GlowBox:1544868870974738565> **Puerto →** 19132`,
    `<:shop_GlowBox:1544868880596602902> **Tienda →** ¡Próximamente!`
  ].join("\n");

  return new EmbedBuilder()
    .setColor(COLOR)
    .setDescription(description)
    .setThumbnail(getUserAvatar(member.user))
    .setImage(member.guild.iconURL({ extension: "png", size: 1024 }) || null)
    .setFooter({
      text: `${FOOTER_TEXT} | ${String(now.getDate()).padStart(2,"0")}/${String(now.getMonth()+1).padStart(2,"0")}/${now.getFullYear()} ${now.toLocaleTimeString("es-MX")}`
    });
}

async function sendWelcome(member) {
  const channel = WELCOME_CHANNEL_ID
    ? member.guild.channels.cache.get(WELCOME_CHANNEL_ID)
    : member.guild.systemChannel;

  if (!channel || !channel.isTextBased()) return;
  await channel.send({ embeds: [welcomeEmbed(member)] }).catch(() => {});
}

client.once("ready", async () => {
  console.log(`✅ ${client.user.tag} está conectado.`);
  console.log(`📡 Prefix: ${PREFIX}`);

  // Reanuda sorteos que estaban guardados.
  const giveaways = readJSON(GIVEAWAYS_FILE, []);
  for (const giveaway of giveaways) {
    if (!giveaway.ended) scheduleGiveawayEnd(giveaway);
  }
});

client.on("guildMemberAdd", async member => {
  const blacklist = readJSON(BLACKLIST_FILE, {});
  const entry = blacklist[member.guild.id]?.[member.id];

  if (entry) {
    await member.ban({ reason: `Blacklist: ${entry.reason || "Sin razón"}` }).catch(() => {});
    return;
  }
  await sendWelcome(member);
});

client.on("messageCreate", async message => {
  if (message.author.bot || !message.guild) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = (args.shift() || "").toLowerCase();

  try {
    if (["ban", "unban", "kick", "mute", "unmute", "warn", "unwarn", "warnlist", "blacklist"].includes(command)) {
      if (!hasModPermission(message.member)) {
        return message.reply({ embeds: [modEmbed("⛔ Sin permisos", "No tienes permisos para usar este comando.")] });
      }
    }

    if (command === "ban") {
      const member = getMemberFromMention(message, args[0]);
      if (!member) return message.reply("Uso: `!ban @usuario [razón]`");
      if (!member.bannable) return message.reply("❌ No puedo banear a ese usuario.");
      const reason = cleanReason(args, 1);
      await member.ban({ reason });
      return message.channel.send({ embeds: [modEmbed("🔨 Usuario baneado", `**Usuario:** ${member.user.tag}\n**Razón:** ${reason}\n**Moderador:** ${message.author}`)] });
    }

    if (command === "unban") {
      const id = (args[0] || "").replace(/\D/g, "");
      if (!id) return message.reply("Uso: `!unban ID [razón]`");
      const reason = cleanReason(args, 1);
      await message.guild.members.unban(id, reason);
      return message.channel.send({ embeds: [modEmbed("🔓 Usuario desbaneado", `**ID:** ${id}\n**Razón:** ${reason}`)] });
    }

    if (command === "kick") {
      const member = getMemberFromMention(message, args[0]);
      if (!member) return message.reply("Uso: `!kick @usuario [razón]`");
      if (!member.kickable) return message.reply("❌ No puedo expulsar a ese usuario.");
      const reason = cleanReason(args, 1);
      await member.kick(reason);
      return message.channel.send({ embeds: [modEmbed("👢 Usuario expulsado", `**Usuario:** ${member.user.tag}\n**Razón:** ${reason}`)] });
    }

    if (command === "mute") {
      const member = getMemberFromMention(message, args[0]);
      const duration = parseDuration(args[1]);
      if (!member || !duration) return message.reply("Uso: `!mute @usuario 10m [razón]`");
      if (!member.moderatable) return message.reply("❌ No puedo silenciar a ese usuario.");
      const reason = cleanReason(args, 2);
      await member.timeout(duration, reason);
      return message.channel.send({ embeds: [modEmbed("🔇 Usuario silenciado", `**Usuario:** ${member.user.tag}\n**Duración:** ${formatDuration(duration)}\n**Razón:** ${reason}`)] });
    }

    if (command === "unmute") {
      const member = getMemberFromMention(message, args[0]);
      if (!member) return message.reply("Uso: `!unmute @usuario`");
      await member.timeout(null, "Unmute manual");
      return message.channel.send({ embeds: [modEmbed("🔊 Silencio retirado", `Se retiró el silencio de ${member}.`)] });
    }

    if (command === "warn") {
      const member = getMemberFromMention(message, args[0]);
      if (!member) return message.reply("Uso: `!warn @usuario [razón]`");
      const reason = cleanReason(args, 1);
      const warns = readJSON(WARNS_FILE, {});
      warns[message.guild.id] ||= {};
      warns[message.guild.id][member.id] ||= [];
      warns[message.guild.id][member.id].push({
        reason,
        moderator: message.author.id,
        date: Date.now()
      });
      writeJSON(WARNS_FILE, warns);
      return message.channel.send({ embeds: [modEmbed("⚠️ Advertencia", `${member} recibió una advertencia.\n**Razón:** ${reason}\n**Total:** ${warns[message.guild.id][member.id].length}`)] });
    }

    if (command === "unwarn") {
      const member = getMemberFromMention(message, args[0]);
      const number = Number(args[1]);
      const warns = readJSON(WARNS_FILE, {});
      const list = warns[message.guild.id]?.[member?.id];
      if (!member || !list?.length || !Number.isInteger(number) || number < 1 || number > list.length) {
        return message.reply("Uso: `!unwarn @usuario número`");
      }
      const removed = list.splice(number - 1, 1)[0];
      writeJSON(WARNS_FILE, warns);
      return message.channel.send({ embeds: [modEmbed("✅ Advertencia eliminada", `${member} — advertencia #${number} eliminada.\n**Razón:** ${removed.reason}`)] });
    }

    if (command === "warnlist") {
      const member = getMemberFromMention(message, args[0]) || message.member;
      const warns = readJSON(WARNS_FILE, {});
      const list = warns[message.guild.id]?.[member.id] || [];
      const lines = list.length
        ? list.map((w, i) => `**#${i + 1}** — ${w.reason} — <@${w.moderator}>`).join("\n")
        : "No tiene advertencias.";
      return message.channel.send({ embeds: [modEmbed(`📋 Warnlist de ${member.user.tag}`, lines)] });
    }

    if (command === "blacklist") {
      const sub = (args[0] || "").toLowerCase();
      const blacklist = readJSON(BLACKLIST_FILE, {});
      blacklist[message.guild.id] ||= {};

      if (sub === "list") {
        const entries = Object.entries(blacklist[message.guild.id]);
        const text = entries.length
          ? entries.map(([id, e]) => `• <@${id}> — ${e.reason || "Sin razón"}`).join("\n")
          : "La blacklist está vacía.";
        return message.channel.send({ embeds: [modEmbed("🚫 Blacklist", text)] });
      }

      if (sub === "remove") {
        const member = getMemberFromMention(message, args[1]);
        const id = member?.id || (args[1] || "").replace(/\D/g, "");
        if (!id || !blacklist[message.guild.id][id]) return message.reply("Ese usuario no está en la blacklist.");
        delete blacklist[message.guild.id][id];
        writeJSON(BLACKLIST_FILE, blacklist);
        return message.channel.send({ embeds: [modEmbed("✅ Blacklist actualizada", `<@${id}> fue retirado de la blacklist.`)] });
      }

      const member = getMemberFromMention(message, args[0]);
      if (!member) return message.reply("Uso: `!blacklist @usuario [razón]` o `!blacklist remove @usuario`");
      const reason = cleanReason(args, 1);
      blacklist[message.guild.id][member.id] = { reason, date: Date.now() };
      writeJSON(BLACKLIST_FILE, blacklist);
      await member.ban({ reason: `Blacklist: ${reason}` }).catch(() => {});
      return message.channel.send({ embeds: [modEmbed("🚫 Usuario en blacklist", `${member.user.tag} fue agregado a la blacklist y baneado.\n**Razón:** ${reason}`)] });
    }

    if (command === "ip") {
      const embed = footer(new EmbedBuilder()
        .setColor(COLOR)
        .setTitle("GlowBox〢Network")
        .setDescription([
          "> El servidor se encuentra actualmente en creación",
          "",
          "🖥️ **IP:** ¡Próximamente!",
          "🌴 **Puerto:** 19132",
          "",
          "🔩 Que esperas para entrar a jugar y dominar la modalidad que estará próximamente"
        ].join("\n")));
      return message.channel.send({ embeds: [embed] });
    }

    if (command === "icon") {
      let user = message.mentions.users.first();
      if (!user && message.reference?.messageId) {
        const referenced = await message.fetchReference().catch(() => null);
        user = referenced?.author || null;
      }
      user ||= message.author;

      const embed = footer(new EmbedBuilder()
        .setColor(COLOR)
        .setTitle(`🖼️ Avatar de ${user.tag}`)
        .setImage(getUserAvatar(user))
        .setURL(getUserAvatar(user)));
      return message.channel.send({ embeds: [embed] });
    }

    if (command === "server") {
      const sub = (args[0] || "").toLowerCase();
      if (sub === "icon") {
        const icon = message.guild.iconURL({ extension: "png", size: 4096 });
        const embed = footer(new EmbedBuilder()
          .setColor(COLOR)
          .setTitle(`${message.guild.name} — Icono`)
          .setImage(icon || null)
          .setURL(icon || null));
        return message.channel.send({ embeds: [embed] });
      }

      const g = message.guild;
      const created = `<t:${Math.floor(g.createdTimestamp / 1000)}:F>`;
      const owner = await client.users.fetch(g.ownerId).catch(() => null);
      const emojis = g.emojis.cache.size;
      const stickers = g.stickers.cache.size;
      const channels = g.channels.cache.size;
      const roles = g.roles.cache.size;
      const boosts = g.premiumTier === 0 ? "Nivel 0" : `Nivel ${g.premiumTier}`;

      const embed = footer(new EmbedBuilder()
        .setColor(COLOR)
        .setAuthor({ name: g.name, iconURL: g.iconURL({ extension: "png" }) || undefined })
        .setDescription(`Información de **${g.name}**`)
        .addFields(
          { name: "👑 Dueño", value: owner ? `${owner.tag}\n\`${g.ownerId}\`` : `\`${g.ownerId}\``, inline: true },
          { name: "🆔 ID", value: `\`${g.id}\``, inline: true },
          { name: "📅 Creación", value: created, inline: true },
          { name: "👥 Miembros", value: `${g.memberCount}`, inline: true },
          { name: "💬 Canales", value: `${channels}`, inline: true },
          { name: "🎭 Roles", value: `${roles}`, inline: true },
          { name: "✨ Stickers", value: `${stickers}`, inline: true },
          { name: "😀 Emojis", value: `${emojis}`, inline: true },
          { name: "🚀 Boost", value: boosts, inline: true },
          { name: "🛡️ Verificación", value: String(g.verificationLevel).replaceAll("_", " ").toLowerCase(), inline: true }
        )
        .setThumbnail(g.iconURL({ extension: "png", size: 1024 }) || null));

      return message.channel.send({ embeds: [embed] });
    }

    if (command === "setwelcome") {
      if (!hasAdminPermission(message.member)) return message.reply("⛔ Necesitas permisos de administrador.");
      const channel = message.mentions.channels.first();
      if (!channel) return message.reply("Uso: `!setwelcome #bienvenidas`");
      // Nota: para mantener el proyecto simple, el canal también puede ponerse directamente en .env.
      return message.channel.send({ embeds: [modEmbed("📌 Canal de bienvenida", `Tu canal es ${channel}.\n\nPara dejarlo fijo, pon su ID en \`WELCOME_CHANNEL_ID\` dentro de \`.env\`.`)] });
    }

    if (command === "testwelcome") {
      if (!hasAdminPermission(message.member)) return message.reply("⛔ Necesitas permisos de administrador.");
      await message.channel.send({ embeds: [welcomeEmbed(message.member)] });
      return;
    }

    if (command === "giveaway") {
      if (!hasModPermission(message.member)) return message.reply("⛔ Necesitas permisos de moderación.");
      const parsed = parseGiveawayArgs(args);
      if (!parsed) {
        return message.reply("Uso: `!giveaway <premio> <duración> [ganadores] [@host]`\nEjemplo: `!giveaway Rango VIP 2h 1 @Axel`");
      }

      const hostUser = message.mentions.users.first() || message.author;
      const endAt = Date.now() + parsed.duration;

      const embed = footer(new EmbedBuilder()
        .setColor(COLOR)
        .setTitle("🎉 SORTEO")
        .setDescription([
          `🎁 **Premio:** ${parsed.prize}`,
          `⏱️ **Duración:** ${formatDuration(parsed.duration)}`,
          `🏆 **Ganadores:** ${parsed.winners}`,
          `👤 **Host:** ${hostUser}`,
          "",
          "**Haz clic en 🎉 para participar.**"
        ].join("\n"))
        .addFields({ name: "Termina", value: `<t:${Math.floor(endAt / 1000)}:R>` })
        .setTimestamp(endAt));

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("giveaway_join").setEmoji("🎉").setLabel("Participar").setStyle(ButtonStyle.Primary)
      );

      const sent = await message.channel.send({ embeds: [embed], components: [row] });

      const giveaway = {
        messageId: sent.id,
        channelId: sent.channel.id,
        guildId: message.guild.id,
        prize: parsed.prize,
        winners: parsed.winners,
        hostId: hostUser.id,
        endAt,
        participants: [],
        ended: false
      };

      const giveaways = readJSON(GIVEAWAYS_FILE, []);
      giveaways.push(giveaway);
      writeJSON(GIVEAWAYS_FILE, giveaways);
      scheduleGiveawayEnd(giveaway);
      return;
    }

    if (command === "reroll") {
      if (!hasModPermission(message.member)) return message.reply("⛔ Necesitas permisos de moderación.");
      const messageId = args[0];
      if (!messageId) return message.reply("Uso: `!reroll ID_DEL_MENSAJE`");

      const giveaways = readJSON(GIVEAWAYS_FILE, []);
      const giveaway = giveaways.find(g => g.messageId === messageId && g.guildId === message.guild.id);
      if (!giveaway) return message.reply("❌ No encontré ese sorteo en la base de datos.");

      const valid = [...new Set(giveaway.participants)].filter(id => id !== giveaway.lastWinnerId);
      if (!valid.length) return message.reply("❌ No quedan participantes válidos para hacer reroll.");

      const newWinnerId = valid[Math.floor(Math.random() * valid.length)];
      giveaway.lastWinnerId = newWinnerId;
      writeJSON(GIVEAWAYS_FILE, giveaways);

      return message.channel.send({ embeds: [modEmbed("🔄 Reroll realizado", `🎉 Nuevo ganador: <@${newWinnerId}>\n\nEl ganador debe reclamar su premio según las reglas de tu servidor.`)] });
    }

    if (command === "help" || command === "ayuda") {
      const embed = footer(new EmbedBuilder()
        .setColor(COLOR)
        .setTitle("📚 GlowBox〢Network — Comandos")
        .setDescription([
          "**Moderación**",
          "`!ban` `!unban` `!kick` `!mute` `!unmute`",
          "`!warn` `!unwarn` `!warnlist` `!blacklist`",
          "",
          "**Servidor**",
          "`!ip` `!icon` `!server` `!server icon`",
          "",
          "**Sorteos**",
          "`!giveaway` `!reroll`",
          "",
          "**Bienvenida**",
          "`!setwelcome #canal` `!testwelcome`"
        ].join("\n")));
      return message.channel.send({ embeds: [embed] });
    }
  } catch (error) {
    console.error(error);
    return message.reply({ embeds: [modEmbed("❌ Error", "Ocurrió un error al ejecutar el comando. Revisa la consola del bot.")] }).catch(() => {});
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId !== "giveaway_join") return;

  const giveaways = readJSON(GIVEAWAYS_FILE, []);
  const giveaway = giveaways.find(g => g.messageId === interaction.message.id);

  if (!giveaway || giveaway.ended) {
    return interaction.reply({ content: "❌ Este sorteo ya terminó.", ephemeral: true });
  }

  if (!giveaway.participants.includes(interaction.user.id)) {
    giveaway.participants.push(interaction.user.id);
    writeJSON(GIVEAWAYS_FILE, giveaways);
    return interaction.reply({ content: "🎉 ¡Ya estás participando en el sorteo!", ephemeral: true });
  }

  giveaway.participants = giveaway.participants.filter(id => id !== interaction.user.id);
  writeJSON(GIVEAWAYS_FILE, giveaways);
  return interaction.reply({ content: "↩️ Saliste del sorteo.", ephemeral: true });
});

async function scheduleGiveawayEnd(giveaway) {
  const delay = Math.max(1000, giveaway.endAt - Date.now());

  setTimeout(async () => {
    const giveaways = readJSON(GIVEAWAYS_FILE, []);
    const current = giveaways.find(g => g.messageId === giveaway.messageId);
    if (!current || current.ended) return;

    current.ended = true;

    const channel = await client.channels.fetch(current.channelId).catch(() => null);
    const msg = channel ? await channel.messages.fetch(current.messageId).catch(() => null) : null;

    const participants = [...new Set(current.participants)];
    let winners = [];

    for (let i = 0; i < Math.min(current.winners, participants.length); i++) {
      const available = participants.filter(id => !winners.includes(id));
      winners.push(available[Math.floor(Math.random() * available.length)]);
    }

    current.lastWinnerId = winners[0] || null;
    writeJSON(GIVEAWAYS_FILE, giveaways);

    if (!channel) return;

    const winnerText = winners.length
      ? winners.map(id => `<@${id}>`).join(", ")
      : "No hubo participantes.";

    const embed = footer(new EmbedBuilder()
      .setColor(COLOR)
      .setTitle("🎉 SORTEO FINALIZADO")
      .setDescription([
        `🎁 **Premio:** ${current.prize}`,
        `🏆 **Ganador(es):** ${winnerText}`,
        `👤 **Host:** <@${current.hostId}>`,
        "",
        "Si el ganador no reclama el premio dentro del tiempo indicado por el staff, puedes usar `!reroll ID_DEL_MENSAJE`."
      ].join("\n")));

    await channel.send({ embeds: [embed] }).catch(() => {});
    if (msg) await msg.edit({ components: [] }).catch(() => {});
  }, Math.min(delay, 2147483647));
}

client.login(process.env.DISCORD_TOKEN);
