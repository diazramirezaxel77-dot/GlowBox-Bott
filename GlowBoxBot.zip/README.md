# GlowBox〢Network Bot 🚀

Bot personalizado para Discord hecho con discord.js v14.

## Antes de iniciarlo

1. Instala Node.js 20 o superior.
2. Copia `.env.example` y renómbralo a `.env`.
3. Pon el token de tu bot en `DISCORD_TOKEN`.
4. En el Developer Portal activa estos intents:
   - Server Members Intent
   - Message Content Intent
5. En la carpeta del proyecto ejecuta:
   `npm install`
6. Inicia:
   `npm start`

## Comandos principales

### Moderación
- `!ban @usuario [razón]`
- `!unban ID [razón]`
- `!kick @usuario [razón]`
- `!mute @usuario [duración] [razón]`
- `!unmute @usuario`
- `!warn @usuario [razón]`
- `!unwarn @usuario [número]`
- `!warnlist @usuario`
- `!blacklist @usuario [razón]`
- `!blacklist remove @usuario`
- `!blacklist list`

### Información
- `!ip`
- `!icon @usuario`
- Responde a un mensaje y usa `!icon`
- `!server`
- `!server icon`
- `!server info`

### Bienvenida
- `!setwelcome #canal`
- `!testwelcome`

### Sorteos
- `!giveaway <premio> <duración> [ganador(es)] [host opcional]`
- Ejemplo: `!giveaway Nitro 30m`
- Ejemplo: `!giveaway Rango VIP 2h 2 @Usuario`
- `!reroll ID_DEL_MENSAJE`

Duraciones aceptadas:
- `m` = minutos
- `h` = horas
- `d` = días
- `s` = semanas
- `ms` = meses (30 días)
- `a` = años (365 días)

El giveaway se crea con un botón 🎉 para participar. El host y el premio son obligatorios; la duración es obligatoria. El host es opcional y, si no se indica, se usa quien ejecutó el comando.

## Importante

El bot guarda advertencias, blacklist y sorteos en la carpeta `data/`.
No compartas tu `.env` ni el token del bot.
